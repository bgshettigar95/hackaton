import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-location-weather',
  templateUrl: './location-weather.component.html',
  styleUrls: ['./location-weather.component.css']
})
export class LocationWeatherComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
