import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DashboardComponent } from './dashboard/dashboard.component';
import { MatDividerModule } from '@angular/material/divider';
import { OrderComponent } from './widget/order/order.component';
import { LoadComponent } from './widget/load/load.component';
import { AccountComponent } from './widget/account/account.component';
import { LocationWeatherComponent } from './widget/location-weather/location-weather.component';
import { StatusComponent } from './widget/status/status.component';
import { OptimizeEngineComponent } from './widget/optimize-engine/optimize-engine.component';
import { PlannerUsedComponent } from './widget/planner-used/planner-used.component';
import { ActiveUsersComponent } from './widget/active-users/active-users.component';
import { HighchartsChartModule } from 'highcharts-angular';

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    OrderComponent,
    LoadComponent,
    AccountComponent,
    LocationWeatherComponent,
    StatusComponent,
    OptimizeEngineComponent,
    PlannerUsedComponent,
    ActiveUsersComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatDividerModule,
    HighchartsChartModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
