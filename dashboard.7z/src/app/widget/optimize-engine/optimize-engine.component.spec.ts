import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OptimizeEngineComponent } from './optimize-engine.component';

describe('OptimizeEngineComponent', () => {
  let component: OptimizeEngineComponent;
  let fixture: ComponentFixture<OptimizeEngineComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OptimizeEngineComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OptimizeEngineComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
