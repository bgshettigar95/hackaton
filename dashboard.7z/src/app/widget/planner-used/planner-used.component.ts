import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-planner-used',
  templateUrl: './planner-used.component.html',
  styleUrls: ['./planner-used.component.css']
})
export class PlannerUsedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
