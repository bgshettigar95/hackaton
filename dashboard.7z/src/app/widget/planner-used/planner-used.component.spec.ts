import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PlannerUsedComponent } from './planner-used.component';

describe('PlannerUsedComponent', () => {
  let component: PlannerUsedComponent;
  let fixture: ComponentFixture<PlannerUsedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PlannerUsedComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PlannerUsedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
